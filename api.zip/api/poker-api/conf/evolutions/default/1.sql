# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table card (
  id                            bigint auto_increment not null,
  suit                          integer not null,
  value                         integer not null,
  constraint pk_card primary key (id)
);

create table deck (
  id                            bigint auto_increment not null,
  deck_number                   integer not null,
  constraint pk_deck primary key (id)
);

create table game (
  id                            bigint auto_increment not null,
  game_name                     varchar(255),
  constraint pk_game primary key (id)
);

create table player (
  id                            bigint auto_increment not null,
  player_name                   varchar(255),
  constraint pk_player primary key (id)
);


# --- !Downs

drop table if exists card;

drop table if exists deck;

drop table if exists game;

drop table if exists player;


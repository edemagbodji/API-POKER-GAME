package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import models.Game;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.List;

public class GameController extends Controller {

    public Result getAllGame(){
        List<Game> data = Game.find.all();
        return ok(Json.toJson(data));
    }

    public Result createGame(){

        JsonNode json = request().body().asJson();

        Game data = Json.fromJson(json, Game.class);

        if(data==null){
            return badRequest("miss parameters");
        }

        data.save();

        return ok(Json.toJson(data));
    }

    public Result deleteGame(Long id){
        Game game = Game.find.byId(id);
        if (game==null){
            return notFound("Game not exists");
        }
        game.delete();
        return ok(Json.toJson(game));
    }
}

package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import models.*;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DeckController extends Controller {

    public Result getAllDeck(){
        List<Deck> data = Deck.find.all();
        return ok(Json.toJson(data));
    }

    public Result createDeck(){

        JsonNode json = request().body().asJson();

        Deck data = Json.fromJson(json, Deck.class);

        if(data==null){
            return badRequest("miss parameters");
        }

        data.save();

        return ok(Json.toJson(data));
    }

    public Result deleteDeck(Long id){
        Deck deck = Deck.find.byId(id);
        if (deck==null){
            return notFound("Game not exists");
        }
        deck.delete();
        return ok(Json.toJson(deck));
    }

    public Result addDeckToGame(){
        try{
            JsonNode json = request().body().asJson();
            Long deckId = json.findPath("deckId").asLong();
            Long gameId = json.findPath("gameId").asLong();

            Deck deck = Deck.find.byId(deckId);
            if (deck==null){
                return notFound("Error");
            }

            if (!deck.getInUse()){
                Game game = Game.find.byId(gameId);

                if (game==null){
                    return notFound("Error");
                }

                GameDecks gd = new GameDecks();
                gd.setDeck(deck);
                gd.setGame(game);

                gd.save();
                deck.setInUse(true);
                deck.update();
                return ok(Json.toJson(gd));
            }else {
                return badRequest("Deck is occuped");
            }


        }catch (Exception e){
            return badRequest("Error");
        }
    }

    public Result addPlayerToDeck(){
        try {

            JsonNode json = request().body().asJson();
            Long playerId = json.findPath("playerId").asLong();
            Long deckId = json.findPath("deckId").asLong();

            Player player = Player.find.byId(playerId);
            Deck deck = Deck.find.byId(deckId);

            if (player==null||deck==null){
                return notFound("Error");
            }

            Participe participe = new Participe();
            participe.setDeck(deck);
            participe.setPlayer(player);
            participe.setGameDate(new Date());
            participe.save();

            return ok(Json.toJson(participe));

        }catch (Exception e){
            return badRequest("Error");
        }
    }

    public Result removePlayerFromDeck(){
        try {

            JsonNode json = request().body().asJson();
            Long playerId = json.findPath("playerId").asLong();
            Long deckId = json.findPath("deckId").asLong();

            Player player = Player.find.byId(playerId);
            Deck deck = Deck.find.byId(deckId);

            if (player==null||deck==null){
                return notFound("Error");
            }

            Participe participe = Participe.getByPlayerAndDeck(playerId,deckId);

            participe.delete();

            return ok(Json.toJson(participe));

        }catch (Exception e){
            return badRequest("Error");
        }
    }

    public Result dealCard(){
        try {
            JsonNode json = request().body().asJson();
            Long deckId = json.findPath("deckId").asLong();
            Long playerId = json.findPath("playerId").asLong();
            Player player = Player.find.byId(playerId);
            boolean available;
            Long cardId ;
            List<DeckCards> deckCardsList = DeckCards.getCardsByDeck(deckId);
            int nbAvailable = 0;
            for (DeckCards ac: deckCardsList){
                if(ac.getAvailabe())
                    nbAvailable++;
            }
            if (nbAvailable==0){
                return forbidden("No card available");
            }

            do {
                cardId = 1 + (long)(Math.random() * (52));
                DeckCards ac = DeckCards.getAvailableCardDeck(cardId,deckId);
                available = ac.getAvailabe();
            }while (!available);

            Card card = Card.find.byId(cardId);
            HoldCards hc = new HoldCards();

            hc.setCard(card);
            hc.setPlayer(player);

            hc.save();

            return ok(Json.toJson(hc));
        }catch (Exception e){
            return badRequest("Error");
        }
    }

    public Result getHoldedCards(Long playerId){
        List<HoldCards> data = HoldCards.getHoldedCardsByPlayer(playerId);
        return ok(Json.toJson(data));
    }

    /*public Result getDetailsOfHoldedCards(Long deckId){

        try {
            List<HoldCards> data = HoldCards.getHoldedCardsByPlayer(playerId);
            for (HoldCards hc:data){

            }

            return ok();
        }catch (Exception e){
            return badRequest("Error");
        }
    }*/

    public Result getUndealtCards(Long deckId){
        List<DeckCards> deckCardsList = DeckCards.getUndealtCardsByDeck(deckId);
        List<Card> undealtCards = new ArrayList<>();
        for (DeckCards ac: deckCardsList){
            undealtCards.add(ac.getCard());
        }
        return ok(Json.toJson(undealtCards));
    }

    public Result shuffleDeck(Long deckId){
        List<DeckCards> deckCardsList = DeckCards.getCardsByDeck(deckId);
        List<Integer> randomOrder = new ArrayList<>();
        do {
            Integer order = 1 + (int) (Math.random() * (52));
            if (!randomOrder.contains(order)){
                randomOrder.add(order);
            }
        }while(randomOrder.size()<52);

        for (DeckCards dc:deckCardsList){
            dc.setOrder(randomOrder.get(0));
            randomOrder.remove(randomOrder.get(0));
        }
        return ok();
    }

}

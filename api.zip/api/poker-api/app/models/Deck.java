package models;

import com.sun.org.apache.xpath.internal.operations.Bool;
import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "deck")
public class Deck extends BaseModel {
    

    private int deckNumber;

    private Boolean inUse = Boolean.FALSE;

    public  static Finder<Long, Deck> find = new Finder<>(Deck.class);

    public Deck() {
    }

    public int getDeckNumber() {
        return deckNumber;
    }

    public void setDeckNumber(int deckNumber) {
        this.deckNumber = deckNumber;
    }


    public Boolean getInUse() {
        return inUse;
    }

    public void setInUse(Boolean inUse) {
        this.inUse = inUse;
    }
}

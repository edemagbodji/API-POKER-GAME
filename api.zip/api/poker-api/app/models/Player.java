package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "player")
public class Player extends BaseModel {

    private String playerName;

    public  static Finder<Long, Player> find = new Finder<>(Player.class);

    public static List<Player> getPlayersByDeck(Long deckId){
        List<Player> list = find.query().where().
                eq("deck.id",deckId).findList();
        return list;
    }

    public Player(){
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

   }

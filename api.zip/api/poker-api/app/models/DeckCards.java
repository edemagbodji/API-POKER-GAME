package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "available_cards")
public class DeckCards extends BaseModel {
    private Boolean availabe = Boolean.TRUE;
    private int order;
    @ManyToOne
    private Deck deck;
    @ManyToOne
    private Card card;

    public  static Finder<Long, DeckCards> find = new Finder<>(DeckCards.class);

    public static DeckCards getAvailableCardDeck(Long cardId, Long deckId){
        DeckCards deckCards = find.query().where().
                eq("card.id",cardId).
                eq("deck.id",deckId).findOne();

        return deckCards;
    }

    public static List<DeckCards> getCardsByDeck(Long deckId){
        return find.query().where().eq("deck.id",deckId).findList();
    }

    public static List<DeckCards> getUndealtCardsByDeck(Long deckId){
        return find.query().where().eq("deck.id",deckId).
                eq("availabe",true).findList();
    }

    public DeckCards() {
    }

    public Boolean getAvailabe() {
        return availabe;
    }

    public void setAvailabe(Boolean availabe) {
        this.availabe = availabe;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public Deck getDeck() {
        return deck;
    }

    public void setDeck(Deck deck) {
        this.deck = deck;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }
}

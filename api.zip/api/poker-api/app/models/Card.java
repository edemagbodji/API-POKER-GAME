package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author acer
 */
@Entity
@Table(name = "card")
public class Card extends BaseModel {

    private String suit;
    private int value;

    public  static Finder<Long, Card> find = new Finder<>(Card.class);
    public Card() {
    }

    public Card(int value, String suit) {
        this.value = value;
        this.suit = suit;
    }

    public String getSuit() {
        return suit;
    }

    public void setSuit(String suit) {
        this.suit = suit;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}

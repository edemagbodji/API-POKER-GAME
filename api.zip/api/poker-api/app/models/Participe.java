package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "participe")
public class Participe extends BaseModel {

    private Date gameDate;

    @ManyToOne
    private Deck deck;
    @ManyToOne
    private Player player;


    public  static Finder<Long, Participe> find = new Finder<>(Participe.class);

    public Participe() {
    }

    public static Participe getByPlayerAndDeck(Long playerId,Long deckId){
        Participe participe = find.query().where().
                eq("player.id",playerId).
                eq("deck.id",deckId).findOne();

        return participe;
    }

    public Date getGameDate() {
        return gameDate;
    }

    public void setGameDate(Date gameDate) {
        this.gameDate = gameDate;
    }

    public Deck getDeck() {
        return deck;
    }

    public void setDeck(Deck deck) {
        this.deck = deck;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
}

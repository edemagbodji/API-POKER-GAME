package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "game_deck")
public class GameDecks extends BaseModel {

    @ManyToOne
    private Deck deck;
    @ManyToOne
    private Game game;

    public  static Finder<Long, GameDecks> find = new Finder<>(GameDecks.class);

    public GameDecks() {
    }


    public Deck getDeck() {
        return deck;
    }

    public void setDeck(Deck deck) {
        this.deck = deck;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }
}

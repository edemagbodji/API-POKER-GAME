package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "game")
public class Game extends BaseModel {

    private String gameName;

    public  static Finder<Long, Game> find = new Finder<>(Game.class);

    public Game() {
    }

    public Game(String gameName) {
        this.gameName = gameName;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

}

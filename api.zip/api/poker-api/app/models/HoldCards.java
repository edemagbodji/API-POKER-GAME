package models;

import io.ebean.Finder;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "hold_cards")
public class HoldCards extends BaseModel {


    @ManyToOne
    private Card card;
    @ManyToOne
    private Player player;


    public  static Finder<Long, HoldCards> find = new Finder<>(HoldCards.class);


    public static List<HoldCards> getHoldedCardsByPlayer(Long playerId){
        return find.query().where().eq("player.id",playerId).findList();
    }


    public HoldCards() {
    }

    public Card getCard() {
        return card;
    }



    public void setCard(Card card) {
        this.card = card;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
}

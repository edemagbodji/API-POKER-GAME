/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  21/12/2018 12:00:12                      */
/*==============================================================*/


drop table if exists CARD;

drop table if exists DECK;

drop table if exists DECK_CARDS;

drop table if exists GAME;

drop table if exists GAME_DECKS;

drop table if exists HOLD_CARDS;

drop table if exists PARTICIPE;

drop table if exists PLAYER;

/*==============================================================*/
/* Table : CARD                                                 */
/*==============================================================*/
create table CARD
(
   ID                   int not null auto_increment,
   C_VALUE              int,
   C_SUIT               varchar(20),
   primary key (ID)
);

/*==============================================================*/
/* Table : DECK                                                 */
/*==============================================================*/
create table DECK
(
   ID                   int not null auto_increment,
   NUMBER               int,
   IN_USE               bool,
   primary key (ID)
);

/*==============================================================*/
/* Table : DECK_CARDS                                           */
/*==============================================================*/
create table DECK_CARDS
(
   ID                   int not null auto_increment,
   CARD_ID              int not null,
   DECK_ID              int not null,
   AVAILABLE            bool,
   "ORDER"              int,
   primary key (ID)
);

/*==============================================================*/
/* Table : GAME                                                 */
/*==============================================================*/
create table GAME
(
   ID                   int not null auto_increment,
   NAME                 varchar(100),
   primary key (ID)
);

/*==============================================================*/
/* Table : GAME_DECKS                                           */
/*==============================================================*/
create table GAME_DECKS
(
   ID                   int not null auto_increment,
   GAME_ID              int not null,
   DECK_ID              int not null,
   primary key (ID)
);

/*==============================================================*/
/* Table : HOLD_CARDS                                           */
/*==============================================================*/
create table HOLD_CARDS
(
   ID                   int not null auto_increment,
   CARD_ID              int not null,
   PLAYER_ID            int not null,
   HOLD                 bool,
   primary key (ID)
);

/*==============================================================*/
/* Table : PARTICIPE                                            */
/*==============================================================*/
create table PARTICIPE
(
   ID                   int not null auto_increment,
   DECK_ID              int not null,
   PLAYER_ID            int not null,
   GAME_DATE            date,
   primary key (ID)
);

/*==============================================================*/
/* Table : PLAYER                                               */
/*==============================================================*/
create table PLAYER
(
   ID                   int not null auto_increment,
   PLAYER_NAME          varchar(100),
   primary key (ID)
);

alter table DECK_CARDS add constraint FK_ASSOCIATION_10 foreign key (CARD_ID)
      references CARD (ID) on delete restrict on update restrict;

alter table DECK_CARDS add constraint FK_ASSOCIATION_9 foreign key (DECK_ID)
      references DECK (ID) on delete restrict on update restrict;

alter table GAME_DECKS add constraint FK_ASSOCIATION_7 foreign key (DECK_ID)
      references DECK (ID) on delete restrict on update restrict;

alter table GAME_DECKS add constraint FK_ASSOCIATION_8 foreign key (GAME_ID)
      references GAME (ID) on delete restrict on update restrict;

alter table HOLD_CARDS add constraint FK_ASSOCIATION_11 foreign key (CARD_ID)
      references CARD (ID) on delete restrict on update restrict;

alter table HOLD_CARDS add constraint FK_ASSOCIATION_12 foreign key (PLAYER_ID)
      references PLAYER (ID) on delete restrict on update restrict;

alter table PARTICIPE add constraint FK_ASSOCIATION_4 foreign key (PLAYER_ID)
      references PLAYER (ID) on delete restrict on update restrict;

alter table PARTICIPE add constraint FK_ASSOCIATION_5 foreign key (DECK_ID)
      references DECK (ID) on delete restrict on update restrict;

